#include <iostream>
#include <string>
#include "tempo.h"

using namespace std;

//string Carro::dono="Kayo";

int main() {
	Tempo x1(30,40,50);
	x1.imprimir();
	
	Tempo x2(1,2,3);
	x2.imprimir();
	
	Tempo x3 = (x1+x2);
	x3.imprimir();
	
	++x3;
	cout << "imprimir tudo" << endl;
	x1.imprimir();
	x2.imprimir();
	x3.imprimir();
	
	
	return 0;
}

