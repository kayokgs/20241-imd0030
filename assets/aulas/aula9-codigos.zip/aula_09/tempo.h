#include <iostream>
#include <string>

using namespace std;

#ifndef _CLASS_TEMPO_
	#define _CLASS_TEMPO_



class Tempo {
	private:
		int segundos;
		int minutos;
		int horas;
				
		
	public:
		Tempo(int horas_, int minutos_, int segundos_);
		~Tempo();
		void imprimir();
		Tempo operator+(Tempo &t_);
		Tempo operator=(Tempo &t_);
		Tempo operator++();

		
};
#endif
