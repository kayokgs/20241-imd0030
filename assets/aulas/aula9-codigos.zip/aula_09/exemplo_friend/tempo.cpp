#include "tempo.h"



Tempo::Tempo(int horas_, int minutos_, int segundos_){
	//Necessidade de ajustar os limites dos valores
	horas = horas_;
	minutos = minutos_;
	segundos = segundos_;
}



Tempo::~Tempo(){

}

void Tempo::imprimir(){
	cout << endl << "----------" << endl;
	cout << "Horas:\t\t" << horas << endl;
	cout << "Minutos:\t" << minutos << endl;
	cout << "Segundos:\t" << segundos << endl;
	cout << endl << "----------" << endl;
}

Tempo Tempo::operator+(Tempo &t_){
	//Necessidade de ajustar os limites dos valores
	return Tempo(horas+t_.horas, minutos+t_.minutos, segundos+t_.segundos);
}

Tempo Tempo::operator=(Tempo &t_){
	return Tempo(t_.horas, t_.minutos,t_.segundos);
}

Tempo Tempo::operator++(){
	horas++;
	minutos++;
	segundos++;
	return Tempo(horas, minutos, segundos);
}

