#include <iostream>
#include <string>
#include "tempo.h"

using namespace std;

//Esta função não tem como acessar "segundos, minutos e hora" do parâmetro x porque elas são privadas e estão fora do escopo da classe. Colocando a função como amiga DENTRO da classe TEMPO, agora acessa. 
int calculaSegundos(Tempo &x_){
	return (x_.segundos +x_.minutos*60 + x_.horas*60*60);
}

int main() {
	Tempo x1(0,0,1);
	x1.imprimir();
		
	cout << "CalculaSegundos:" << endl << calculaSegundos(x1) << endl;
	
	return 0;
}

