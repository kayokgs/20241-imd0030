#include "carro.h"

void Carro::setPlaca(string placa_){
	 placa = placa_;
}

void Carro::setAno(int ano_){
	 ano = ano_;
}

Carro::Carro(){
	placa = "AAA0000";
	ano = 1500;
}


Carro::Carro(Carro &c_){
	placa = c_.getPlaca();
	ano = c_.getAno();
}


Carro::Carro(string placa_, int ano_){
	placa = placa_;
	ano = ano_;
}

Carro::~Carro(){

}

void Carro::imprimir(){
	cout << placa << " - " << ano << " - "<< dono <<endl;
}

string Carro::getPlaca(){
	return placa;
}

int Carro::getAno(){
	return ano;
}

