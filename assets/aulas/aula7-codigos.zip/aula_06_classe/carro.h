#include <iostream>
#include <string>

using namespace std;

#ifndef _CLASS_CARRO_
	#define _CLASS_CARRO_



class Carro {

	private:
		string placa;
		int ano;
		
		
	public:
		string static dono;
		Carro();
		Carro(string placa_, int ano_);
		Carro(Carro &c_);
		
		~Carro(); //destrutor
		
		void setPlaca(string placa_);
		void setAno(int ano_);
		void imprimir();
		string getPlaca();
		int getAno();

		
};
#endif
