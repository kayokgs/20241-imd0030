#include <iostream>
#include <string>
#include "carro.h"

using namespace std;

//#include "conv.h"

struct carro{
	string placa;
	int ano;
	double velocidade;
	double aceleracao;
	string cor;
	
};


string Carro::dono="Kayo";

int main() {
/*	carro carro1;
	carro1.placa = "ABC1234";
	carro1.ano = 2024;
	cout << carro1.placa << endl << carro1.ano <<endl;*/
	
	/*carro_classe carro2;
	carro2.placa = "ABC";
	carro2.ano = 2024;
	//cout << carro2.placa << " " << carro2.ano << endl;
	carro2.imprime();
	
	carro_classe carro3;
	carro3.placa = "ZXC";
	carro3.ano imprime= 2000;
	carro3.imprime();*/
	
	/*Carro carro4;
	carro4.setPlaca("SOS1290");
	carro4.setAno(1900);
	carro4.imprimir();*/
	
	//Carro carro5;
	//carro5.imprimir();
	//carro5->setPlaca("1231290");
	
	Carro carro6("placa6", 123);
	carro6.imprimir();
	
	Carro carro7("placa7",789);
	carro7.imprimir();
	
	cout<<"---"<<endl;
	
	Carro::dono="Maria";
	carro6.imprimir();
	carro7.imprimir();
	
	return 0;
}

