#include "carro.h"

Carro::~Carro(){
	//Se usou alocação dinâmica, desalocar aqui.
}

Carro::Carro(){
	/* Este construtor chama o construtor sem parâmetros da superclasse antes mesmo de executar.
	 * Para testar, basta alterar um atributo para valor diferente e ver se fica o valor padrão da superclasse ou o valor desta classe.
	*/
	volumePortaMalas = 10.0;
	//cor = "azul"; //padrão da superclasse é "branca"

}


Carro::Carro(string cor_, string modelo_ , int ano_, string placa_, double volumePortaMalas_): Veiculo(cor_, modelo_, ano_, placa_){
	//Alterar informações desta classe
	volumePortaMalas =  volumePortaMalas_;
}


//sobrecarga de funções.

/*
void Carro::ligar(){
	cout << "hummmmm" << endl;
}

void Carro::imprimirDados(){
	cout << endl << "----------" << endl;
	cout << cor << endl;
	cout << modelo << endl;
	cout << ano << endl;
	cout << placa << endl;
	cout << volumePortaMalas << endl;
	cout << "----------" << endl;
}
*/

