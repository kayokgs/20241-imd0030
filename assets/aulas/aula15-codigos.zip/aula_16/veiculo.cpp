#include "veiculo.h"

Veiculo::~Veiculo(){
	//Se usou alocação dinâmica, desalocar aqui.
}

Veiculo::Veiculo(){
	cor = "branca";
	modelo = "0";
	ano = 0;
	placa = "AAA0000";
}

Veiculo::Veiculo(string cor_ , string modelo_, int ano_, string placa_  ){
	cor = cor_ ;
	modelo = modelo_;
	ano = ano_;
	placa = placa_;
}


//Não mudar
void Veiculo::ligar(){
	cout << "vrum" << endl;
}

void Veiculo::imprimirDados(){
	cout << endl << "----------" << endl;
	cout << cor << endl;
	cout << modelo << endl;
	cout << ano << endl;
	cout << placa << endl;
	cout << "----------" << endl;
}

