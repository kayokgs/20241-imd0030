#include <iostream>
#include <string>
#include "veiculo.h"
#include "carro.h"

using namespace std;

int main() {
	//Testes Veículo
	
	Veiculo v1;
	Veiculo v2("vermelha","modelo1",2024,"ABC1234"); 

	
	v1.imprimirDados();
	v1.ligar();
	
	v2.imprimirDados();
	v2.ligar();
	
	/*
	//Teste Carro (herança)
	//Construtor padrão vazio
	Carro c1; //Chama o construtor da superclass sem parâmetros. automaticamente, antes de executar o construtor padrão. 
	c1.imprimirDados(); //este método foi herdado e é público
	
	//Construtor não-vazio
	Carro c2("azul","modelo2",2025,"CBA4321",420.10); 
	c2.imprimirDados();
	
	//Sobrecarga de métodos
	//Utilizando LIGAR da SUPERCLASSE
	c2.ligar();
	//Sobrecarregando LIGAR na CLASSE-DERIVADA (descomentar no carro.h e carro.cpp)
	c2.ligar();
	
	//Método Virtual - imprimirDados()
	//Retire este método do Veiculo.cpp e deixe-o apenas em Veiculo.h. Faça o teste
	*/
	return 0;
}

