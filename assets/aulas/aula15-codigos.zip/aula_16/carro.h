#include <iostream>
#include <string>
#include "veiculo.h"
using namespace std;

#ifndef _CLASS_CARRO_
	#define _CLASS_CARRO_

/* Heranças das classes
 * - Public: não altera a visibilidade dos membros da superclasse
 * - Private: Todos os membros da superclasse são PRIVATE
 * - Protected: Membros públicos e protected são protected. Private continuam sendo private.
*/
class Carro : public Veiculo{
	private:
		double volumePortaMalas;
		
	public:
		Carro();
		Carro(string cor_, string modelo_ , int ano_, string placa_, double volumePortaMalas_);
		~Carro();
		
		//sobrecarga de métodos
		/*
		void ligar();
		void imprimirDados();
		*/
		
		//Método Virtual
		//void imprimirDados();
				
};
#endif
