#include <iostream>
#include <string>

using namespace std;

#ifndef _CLASS_VEICULO_
	#define _CLASS_VEICULO_



class Veiculo {
	private:
		
			
		
	public:
	string cor;
		string modelo;
		int ano;
		string placa;
		Veiculo();
		Veiculo(string cor_, string modelo_ , int ano_, string placa_);
		~Veiculo();
		void ligar();
		void imprimirDados(); //método padrão herdado
		
		//Método Virtual - descomentar quando apropriado
		//virtual void imprimirDados(){};
				
};
#endif
