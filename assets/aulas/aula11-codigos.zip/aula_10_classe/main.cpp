#include <iostream>
#include <string>
#include "par.h"

using namespace std;

//Caso 1

char maximo(char a_, char b_) {return (a_ > b_) ? a_ : b_; }
int maximo(int a_, int b_) {return (a_ > b_) ? a_ : b_; }
float maximo(float a_, float b_) {return (a_ > b_) ? a_ : b_; }
double maximo(double a_, double b_) {return (a_ > b_) ? a_ : b_; }


/*
//Caso 2
template <typename tipo> tipo maximo(tipo a_, tipo b_) {
	return (a_ > b_) ? a_ : b_; 
}

//Caso 5
template <> string maximo(string a_, string b_) {
	cout << " - função especializada - ";
	return ( a_.compare(b_) > 0) ? a_ : b_;

}

//Caso 6
template <typename tipo1, typename tipo2> tipo1 divisao(tipo1 a_, tipo2 b_) {
	return a_/b_; 
}
*/
int main() {

	
	//Caso 1
	cout << endl << "--- CASO 1 ---" << endl;
	cout << "char: " << maximo('a','b') << endl;
	cout << "int: " << maximo(2,1 ) << endl;
	cout << "float: " << maximo(1.,2.) << endl;
	cout << "double: " << maximo(2.,1.) << endl;
	
	/*
	//Caso 2 - Passagem Implícita
	cout << endl << "--- CASO 2 ---" << endl;
	cout << "char: " << maximo('a','b') << endl;
	cout << "int: " << maximo(2,1 ) << endl;
	cout << "float: " << maximo(1.,2.) << endl;
	cout << "double: " << maximo(2.,1.) << endl;
	
	
	//Caso 3 - Passagem Explícita
	cout << endl << "--- CASO 3 ---" << endl;
	cout << "char: " << maximo<char>('a','b') << endl;
	cout << "int: " << maximo<int>(2,1 ) << endl;
	cout << "float: " << maximo<float>(1.,2.) << endl;
	cout << "double: " << maximo<double>(2.,1.) << endl;
	
	
	//Caso 4 - Pode não funcionar (pega o primeiro?!)
	//Deixar descomentado quando comparar com caso 5.
	//Vai tentar enviar "char*" para a função não-especializada
	cout << endl << "--- CASO 4 ---" << endl;
	cout << "String " << maximo("C++","Java") << endl;
	cout << "String " << maximo("Java","C++") << endl;

	
	//Caso 5 - Especializar o Template p n ter erro
	//Crei template especializado em STRING
	cout << endl << "--- CASO 5 ---" << endl;

	cout << "Não especializando - Dá erro" << endl;
	cout << "String: " << maximo("Java","C++") << endl;
	cout << "String: " << maximo("C++","Java") << endl;

	cout << "Especializando em STRING - Funciona" << endl;
	cout << "String: " << maximo<string>("Java","C++") << endl;
	cout << "String: " << maximo<string>("C++","Java") << endl;
	
	
	//Caso 6 - Mais de um tipo na função
	cout << endl << "--- CASO 6 ---" << endl;
	cout << "float / int implícito: " << divisao(2.5,2) << endl;
	cout << "float / int explícito: " << divisao<float,int>(2.5,2) << endl;
	cout << "int / float implícito " << divisao(3,2.0) << endl;
	cout << "int / float explícito " << divisao<int,float>(3,2.0) << endl;
	
	// Usando Classes
	//Caso 7 - Usando classes 
	cout << endl << "--- CASO 7 ---" << endl;
	Par<int> p1(5,2); //Tem que ser explícita.
	p1.imprimir(); //Sai ordenado
	
	//Par p2(2,5); //dá erro

	Par<string> ps("zc","abc");
	ps.imprimir();
	
	//Caso 8 - ParNomeado - Função com atributos com Template
	ParNomeado<int> pn1("nome1",5,2);
	pn1.imprimir();
*/
	
	return 0;
}

