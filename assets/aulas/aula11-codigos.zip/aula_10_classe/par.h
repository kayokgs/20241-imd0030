#include <iostream>
#include <string>

using namespace std;

/*
 * Do ponto de vista do compilador, os templates não são funções ou classes normais. Eles são compilados sob demanda, o que significa que o código de uma função de modelo não é compilado até que seja necessária uma instanciação com argumentos de modelo específicos. Nesse momento, quando uma instanciação é necessária, o compilador gera uma função específica para esses argumentos do modelo.
 
 * Como os modelos são compilados quando necessário, isso impõe uma restrição para projetos com vários arquivos: a implementação (definição) de uma classe ou função de modelo deve estar no mesmo arquivo que sua declaração. Isso significa que não podemos separar a interface em um arquivo de cabeçalho separado e que devemos incluir a interface e a implementação em qualquer arquivo que utilize os modelos.

*/

#ifndef _CLASS_PAR_
	#define _CLASS_PAR_

//Classe Template
template <class T> class Par {
	private:
		T primeiro;
		T segundo;
				
	public:
		//Par(); //retirei temporariamente. Ver sua definição
		Par(T primeiro_, T segundo_);
		~Par();
		void imprimir();
};

//Definição dos métodos
template <class T> Par<T>::Par(T primeiro_, T segundo_){
	if (primeiro_ < segundo_){
		primeiro = primeiro_;
		segundo = segundo_;
	}
	else{
		primeiro = segundo_;
		segundo = primeiro_;
	}
}


template <class T> Par<T>::~Par(){
	cout << endl<<"Destrutor chamado"<<endl;
}


template <class T> void Par<T>::imprimir(){
	cout << endl << "Primeiro: "<<primeiro << " - Segundo: " << segundo << endl;
}

//Removi temporariamente
/*template <class T> Par<T>::Par(){
	primeiro = (T)0; //casting de 0 para o tipo T
	segundo = (T)0;

}*/










// Classe Template Especializado explicitamente (ou completamente/FULL especializada)
template <> class Par<string> {
	private:
		string primeiro;
		string segundo;
				
	public:
		Par(string primeiro_, string segundo_);
		~Par();
		void imprimir();
};









//Classe composta por outras classes com template.
template <class U> class ParNomeado {
	private:
		string nome;
		Par<U> elementos;
				
	public:
		ParNomeado(string nome_, U primeiro_, U segundo_);
		~ParNomeado();
		void imprimir();
};

//Definição dos métodos

template <class U> ParNomeado<U>::ParNomeado(string nome_, U primeiro_, U segundo_): nome(nome_), elementos(primeiro_, segundo_){
	// Para que possamos inicializar ELEMENTOS, é preciso chamar o seu contrutor. Perceba, entretanto, que a classe PAR<U> não tem construtor padrão sem parâmetros. Portanto, para não termos que alocar dinamicamente um PAR<U>, chamamos este construtor pela nova forma de passagem de parâmetros ACIMA.
	
}


//Este construtor é somente usado se ELEMENTOS for um PONTEIRO
/*template <class U> ParNomeado<U>::ParNomeado(string nome_, U primeiro_, U segundo_){
	//Este método somente funciona se existir um construtor sem parâmetros de PAR<U>
	nome = nome_;
	elementos = Par<U>(primeiro_,segundo_);
}*/

template <class U> ParNomeado<U>::~ParNomeado(){
	cout << endl<<"ParNomeado - Destrutor chamado"<<endl;

}

template <class U> void ParNomeado<U>::imprimir(){
	cout << endl << "---ParNomeado---";
	elementos.imprimir();
}




#endif
