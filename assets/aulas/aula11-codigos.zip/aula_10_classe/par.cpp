#include "par.h"

//Nada a acrescentar se Template.
//Se for template especializado, tem que colocar aqui.


//Classe Especializada Par<string>
Par<string>::Par(string primeiro_, string segundo_){

	if (primeiro_.compare(segundo_) < 0){
		primeiro = primeiro_;
		segundo = segundo_;
	}
	else{
		primeiro = segundo_;
		segundo = primeiro_;
	}
}




Par<string>::~Par(){
	cout << endl<<"Destrutor Especializado chamado"<<endl;

}

void Par<string>::imprimir(){
	cout << endl << "Especializado - Primeiro: "<<primeiro << " - Segundo: " << segundo << endl;
}

